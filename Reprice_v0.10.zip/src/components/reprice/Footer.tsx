'use client'

import { Leaf, Recycle, Tag, MapPin } from 'lucide-react'
import { useAppStore } from '@/store/app'
import { Button } from '@/components/ui/button'

export function Footer() {
  const { setView } = useAppStore()
  return (
    <footer className="mt-auto border-t border-border/60 bg-black">
      <div className="mx-auto max-w-6xl px-4 py-6 text-sm text-muted-foreground flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/reprice-logo.png" alt="RePrice" className="h-5 w-auto" />
        <button
          type="button"
          onClick={() => {
            setView('support')
            window.scrollTo({ top: 0 })
          }}
          className="text-xs hover:text-foreground underline-offset-4 hover:underline"
        >
          Suporte e dúvidas frequentes
        </button>
        <p className="text-xs">
          Produtos que ganham uma nova chance · Preços que ganham uma nova vida
        </p>
        <p className="text-xs">© {new Date().getFullYear()} RePrice — Projeto acadêmico</p>
      </div>
    </footer>
  )
}
